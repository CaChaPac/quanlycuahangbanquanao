<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends MY_Model {
	var $table = 'product';
}