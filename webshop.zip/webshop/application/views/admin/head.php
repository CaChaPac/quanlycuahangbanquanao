<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lumino - Dashboard</title>

<link href="<?php echo public_url('admin/'); ?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo public_url('admin/'); ?>css/datepicker3.css" rel="stylesheet">
<link href="<?php echo public_url('admin/'); ?>css/styles.css" rel="stylesheet">
<script src="<?php echo public_url(); ?>js/jquery-3.1.1.js" type="text/javascript"></script>
<script src="<?php echo public_url(); ?>js/jquery.js" type="text/javascript"></script>

<!--Icons-->
<script src="<?php echo public_url('admin/'); ?>js/lumino.glyphs.js"></script>
<script src="<?php echo public_url(); ?>js/ckeditor/ckeditor.js"></script>